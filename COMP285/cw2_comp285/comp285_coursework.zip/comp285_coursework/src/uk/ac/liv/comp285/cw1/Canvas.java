package uk.ac.liv.comp285.cw1;

public class Canvas {
	

}
