/**
 * 
 */
/**
 * @author coopes
 *
 */
module comp285_coursework {
	requires java.desktop;
}