/*
 * COMP201 Assignment 2
 * Person.java
 * NAME: Minhao Jin
 * STUDENT ID: 201447766
 * COMPUTER USERNAME: sgmjin2
 * 
 */
public class Person {
	private String name;

	public Person(String name) {
		this.name = name;
	}

	public String get_name() {
		return name;
	}

}
