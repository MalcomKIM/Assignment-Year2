/*
* Student ID: 201447766
* Student Name: Minhao Jin
* Email: M.Jin5@student.liverpool.ac.uk
*
* User: sgmjin2
*
* Problem ID: 1015
* RunID: 4729
* Result: Accepted
*/

#include<stdio.h>

/*main function*/
int main(void){
	int input=-1;	/*initialize 'input' with a negative value to accept user's input*/

	while(scanf("%d",&input)!=EOF){
		/*keep reading user's input until input is 'EOF'*/
		printf("%c",input);	/*convert the integers to characters and print out*/
	}
	
	return 0;		
}
